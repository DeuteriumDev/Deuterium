--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1.pgdg120+1)
-- Dumped by pg_dump version 16.1 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: document_types; Type: TABLE DATA; Schema: private; Owner: -
--

COPY private.document_types (value, comment) FROM stdin;
\.
COPY private.document_types (value, comment) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: documents; Type: TABLE DATA; Schema: private; Owner: -
--

COPY private.documents (id, inherit_permissions_from_parent, parent_id, type, foreign_id) FROM stdin;
\.
COPY private.documents (id, inherit_permissions_from_parent, parent_id, type, foreign_id) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, parent_id) FROM stdin;
\.
COPY public.groups (id, name, parent_id) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: document_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_permissions (id, can_create, can_read, can_update, can_delete, document_id, group_id) FROM stdin;
\.
COPY public.document_permissions (id, can_create, can_read, can_update, can_delete, document_id, group_id) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folders (id, name, description) FROM stdin;
\.
COPY public.folders (id, name, description) FROM '$$PATH$$/3431.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email) FROM stdin;
\.
COPY public.users (id, email) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_members (group_id, user_id) FROM stdin;
\.
COPY public.group_members (group_id, user_id) FROM '$$PATH$$/3429.dat';

--
-- Data for Name: group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_permissions (id, can_create, can_read, can_update, can_delete, owner_group_id, target_group_id) FROM stdin;
\.
COPY public.group_permissions (id, can_create, can_read, can_update, can_delete, owner_group_id, target_group_id) FROM '$$PATH$$/3426.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

